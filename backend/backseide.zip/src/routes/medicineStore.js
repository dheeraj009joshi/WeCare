const express = require('express');
const router = express.Router();

// Import controllers
const productController = require('../controllers/productController');
const cartController = require('../controllers/cartController');
const orderController = require('../controllers/orderController');
const addressController = require('../controllers/addressController');
const paymentController = require('../controllers/paymentController');

// Import middleware
const auth = require('../middleware/auth');

// Product routes (public)
router.get('/products', productController.getAllProducts);
router.get('/products/categories', productController.getCategories);
router.get('/products/:id', productController.getProductById);

// Cart routes (authenticated users)
router.get('/cart', auth, cartController.getCart);
router.post('/cart/add', auth, cartController.addToCart);
router.put('/cart/:id', auth, cartController.updateCartItem);
router.delete('/cart/:id', auth, cartController.removeFromCart);
router.delete('/cart', auth, cartController.clearCart);
router.get('/cart/summary', auth, cartController.getCartSummary);

// Address routes (authenticated)
router.get('/addresses', auth, addressController.getUserAddresses);
router.post('/addresses', auth, addressController.addAddress);
router.put('/addresses/:id', auth, addressController.updateAddress);
router.delete('/addresses/:id', auth, addressController.deleteAddress);
router.put('/addresses/:id/default', auth, addressController.setDefaultAddress);
router.get('/addresses/default', auth, addressController.getDefaultAddress);

// Payment routes (authenticated users)
router.post('/payment/cod', auth, paymentController.processCODPayment);
router.get('/payment/status/:orderId', auth, paymentController.getPaymentStatus);

// Order routes (authenticated users)
router.post('/orders', auth, orderController.createOrder);
router.get('/orders', auth, orderController.getUserOrders);
router.get('/orders/:id', auth, orderController.getOrderById);
router.put('/orders/:id/cancel', auth, orderController.cancelOrder);
router.get('/orders/status/:orderNumber', orderController.getOrderStatus);

// Admin routes - COMPLETELY REMOVED
// All admin functionality has been removed from the backend

// Test route
router.get('/test', (req, res) => {
  res.json({ message: 'Medicine store API is working! (Admin panel removed)' });
});

module.exports = router;
